package com.demo.dto;

public record ApiSaveHealthRequest(String name, String type) {

}
