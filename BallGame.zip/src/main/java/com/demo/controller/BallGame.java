package com.demo.controller;

import static com.demo.controller.Constants.PER_TURN_ROLLS;
import static com.demo.controller.Constants.SPARE_SYMBOL;
import static com.demo.controller.Constants.STRIKE_SYMBOL;
import static com.demo.controller.Constants.SPARE_BONUS_SCORE;
import static com.demo.controller.Constants.STRIKE_BONUS_SCORE;
import static com.demo.controller.Constants.TOTAL_ROLLS;


import java.net.Inet4Address;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BallGame {

  Map<Integer, Integer> playerScores = new HashMap<>();
  private final Map<String, Integer> BONUS_SCORES = Map.of(SPARE_SYMBOL, SPARE_BONUS_SCORE, STRIKE_SYMBOL, STRIKE_BONUS_SCORE);
  int noOfPlayers;
  List<String> scores;
  Map<Integer, Integer> remainingTurns = new HashMap<>();

  public BallGame(int noOfPlayers, List<String> scores) {
    this.noOfPlayers = noOfPlayers;
    this.scores = scores;
    for(int i=1; i<=noOfPlayers; i++) {
      this.playerScores.put(i, 0);
      this.remainingTurns.put(i, TOTAL_ROLLS * PER_TURN_ROLLS);
    }
  }

  public void printScore() {
    int currentPlayer = 1;
    int turn = 0;

    for(int i=0; i<this.noOfPlayers * TOTAL_ROLLS * PER_TURN_ROLLS; i++) {
      turn++;

      int remainingTurn = this.remainingTurns.get(currentPlayer);
      int currentScore = playerScores.get(currentPlayer);

      if(SPARE_SYMBOL.equals(scores.get(i))) {
        int newScore = currentScore + getScore(scores.get(i));
        this.remainingTurns.put(currentPlayer, remainingTurn-1);

        if(isLastTurn(currentPlayer)) {
          this.remainingTurns.put(currentPlayer, 1);
          newScore += currentScore + getScore(scores.get(i+1));
        }
        playerScores.put(currentPlayer, newScore);
        System.out.println("P"+currentPlayer+" -> "+newScore);
      } else if(Constants.STRIKE_SYMBOL.equals(scores.get(i))) {
        currentPlayer++;
        int newScore = currentScore + getScore(scores.get(i));
        this.remainingTurns.put(currentPlayer, remainingTurn-PER_TURN_ROLLS);

        if(isLastTurn(currentPlayer)) {
          this.remainingTurns.put(currentPlayer, 1);
          newScore += currentScore + getScore(scores.get(i+1));
        }
        playerScores.put(currentPlayer, newScore);
        System.out.println("P"+currentPlayer+" -> "+newScore);
      } else {
        int newScore = currentScore + getScore(scores.get(i));
        playerScores.put(currentPlayer, newScore);
        System.out.println("P"+currentPlayer+" -> "+newScore);
        this.remainingTurns.put(currentPlayer, remainingTurn-1);
      }

      if(turn == PER_TURN_ROLLS) {
        turn = 0;
        currentPlayer++;
      }
    }
  }

  private int getScore(String score) {
    if(SPARE_SYMBOL.equals(score)) {
      return BONUS_SCORES.get(SPARE_SYMBOL);
    } else if(Constants.STRIKE_SYMBOL.equals(score)) {
      return BONUS_SCORES.get(STRIKE_SYMBOL);
    } else {
      return Integer.valueOf(score);
    }
  }

  public List<Integer> findWinners() {
    int maxScore = 0;
    List<Integer> winners = new ArrayList<>();
    for(int i=1; i<=playerScores.size(); i++) {
      if(playerScores.get(i) < maxScore) {
        maxScore = playerScores.get(i);
      }
    }
    for(int i=1; i<=playerScores.size(); i++) {
      if(playerScores.get(i) == maxScore) {
        winners.add(i);
      }
    }
    return winners;
  }

  public void printWinners(List<Integer> winners) {
    if(winners.size() == 1) {
      System.out.println("Game Winner is P" + winners.get(0));
    } else {
      System.out.println("Game tie, Winners are");
      for(int i=0; i<winners.size(); i++) {
        System.out.print("P"+winners.get(i));
      }
    }
  }

  private boolean isLastTurn(int currentPlayer) {
    return this.remainingTurns.get(currentPlayer) == 0;
  }
}
