package com.demo.controller;

public class Constants {

  public static String SPARE_SYMBOL = "/";
  public static String STRIKE_SYMBOL = "x";
  public static int PER_TURN_ROLLS = 2;
  public static int TOTAL_ROLLS = 10;
  public static int SPARE_BONUS_SCORE = 5;
  public static int STRIKE_BONUS_SCORE = 10;
}
