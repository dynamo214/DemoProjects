package com.demo.controller;

import com.demo.dto.ApiSaveHealthRequest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthController {

  @GetMapping("/health")
  public String checkHealth() {
    return HttpStatus.OK.toString();
  }

  @PostMapping("/health")
  public String saveHealth(@RequestBody ApiSaveHealthRequest req) {
    BallGame ballGame = new BallGame(2, List.of("8", "5", "/", "x"));

    ballGame.printScore();
    List<Integer> winners = ballGame.findWinners();
    ballGame.printWinners(winners);

    return "SUCCESS";
  }
}
