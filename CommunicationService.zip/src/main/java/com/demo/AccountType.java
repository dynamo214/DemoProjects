package com.demo;

public enum AccountType {
  Promotional,
  Transactional
}
