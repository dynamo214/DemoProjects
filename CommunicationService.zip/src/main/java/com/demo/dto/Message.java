package com.demo.dto;

import com.demo.Channel;

public record Message(Channel channel) {

}
