package com.demo;

public class SMSVendor2 extends SMSVendor {
  private String authToken;
  private String availabilityEndpoint = "https://smsvendor2/api/health";
}
