package com.demo;

public enum Channel {
  SMS,
  EMAIL,
  WHATSAPP,
  PUSH_NOTIFICATION
}
