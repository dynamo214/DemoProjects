package com.demo.controller;

import com.demo.dto.ApiSaveHealthRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthController {

  @GetMapping("/health")
  public String checkHealth() {
    return HttpStatus.OK.toString();
  }

  @PostMapping("/health")
  public String saveHealth(@RequestBody ApiSaveHealthRequest req) {
    System.out.println(req);
    return "SUCCESS";
  }
}
