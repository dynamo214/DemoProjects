package com.demo.controller;

import static com.demo.Factory.getNotificationHandler;
import com.demo.Channel;
import com.demo.CommunicationVendor;
import com.demo.NotificationHandler;

public class CommunicationService {
/**
 * {
 * "channel": "SMS/Email/WhatsApp/Push",
 * "AccountType": "Promotional/Transactional",
 * "recipients": [{define whatever data you need}]
 * "communicationPayload": {
 * whatever data we need to send communication. This would
 * be based on channel
 * }
 * }
 * 1. recipients -> mobile numbers/emails
 * 2. communicationPayload -> message
 */

 public void sendMessage() {
   NotificationHandler notificationHandler = getNotificationHandler(Channel.valueOf("SMS"));
   CommunicationVendor vendor = notificationHandler.getAvailableVendor();
   vendor.sendMessage();
 }

}
