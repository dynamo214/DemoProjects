package com.demo;

import static com.demo.Channel.SMS;

public class Factory {

  private static SMSNotificationHandler notificationHandler;

  public static NotificationHandler getNotificationHandler(Channel channel) {
    if(channel.equals(SMS)) {
      return notificationHandler;
    }
    return null;
  }

}
