package com.demo;

import org.springframework.stereotype.Service;

@Service
public class SMSNotificationHandler extends NotificationHandler {
  public CommunicationVendor getAvailableVendor() {
    return  SMSVendor.fetchAvailableVendor();
  }
}