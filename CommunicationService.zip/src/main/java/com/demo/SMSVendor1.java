package com.demo;

import org.springframework.beans.factory.annotation.Value;

public class SMSVendor1 extends SMSVendor {

  private String UserName;
  private String Password;
  private String availabilityEndpoint = "https://smsvendor1/api/health";
  private String sendMessageEndpoint = "https://smsvendor1/api/message";

  public boolean isAvailable() {
    // hit availabilityEndpoint and check for availability
    return true;
  }

  public void sendMessage() {
    // hit availabilityEndpoint and check for availability
  }

}