package com.demo;

public class EmailNotificationHandler extends NotificationHandler {
  public CommunicationVendor getAvailableVendor() {
    return  null;
  }
}
