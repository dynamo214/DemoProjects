package com.demo;


public class CommunicationVendor {

  public CommunicationVendor getAvailableVendor() {
    return null;
  }

  public void sendMessage() {
  }
}
