package com.demo;

import java.util.List;

public class SMSVendor extends CommunicationVendor {

  private static List<SMSVendor> smsVendors = List.of(new SMSVendor1(), new SMSVendor2());

  public boolean isAvailable() {
    return true;
  }

  public static SMSVendor fetchAvailableVendor() {
    List<SMSVendor> availableSmsVendors = List.of();
    for(SMSVendor smsVendor:smsVendors) {
      if(smsVendor.isAvailable()) {
        availableSmsVendors.add(smsVendor);
      }
    }

    int index = getRandomNumber(0, availableSmsVendors.size());
    //TODO: add alerting/logging in case no available vendor
    return availableSmsVendors.get(index);
  }

  public static int getRandomNumber(int start, int end) {
    // returns random number
    return 0;
  }

}
