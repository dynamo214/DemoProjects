package com.demo;

import static com.demo.Channel.SMS;

public class NotificationHandler {

  public CommunicationVendor getAvailableVendor() {
    return  null;
  }
}


