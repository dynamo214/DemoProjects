package com.demo.dto;

public enum PaymentMethod {
  UPI,
  CREDIT_CARD,
  DEBIT_CARD,
  NET_BANKING
}
