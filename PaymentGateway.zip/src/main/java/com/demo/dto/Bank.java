package com.demo.dto;

public enum Bank {
  HDFC,
  KOTAK
}
