package com.demo.dto;

import java.util.Map;

public record PaymentRequest(
    PaymentMethod paymentMethod,
    Map<String, String> paymentDetails

) {

}
