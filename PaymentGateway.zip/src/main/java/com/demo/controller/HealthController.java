package com.demo.controller;

import com.demo.dto.ApiSaveHealthRequest;
import com.demo.dto.PaymentRequest;
import com.demo.service.PaymentMethodService.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthController {

  @Autowired
  PaymentService svc;

  @GetMapping("/health")
  public String checkHealth() {
    return HttpStatus.OK.toString();
  }

  @PostMapping("/health")
  public String saveHealth(@RequestBody ApiSaveHealthRequest req) {
    return "SUCCESS";
  }

  @PostMapping("/make-payment")
  public String makePayment(@RequestBody PaymentRequest req) throws Exception {
    svc.makePayment(req);
    return "SUCCESS";
  }

  @GetMapping("/show-distribution")
  public String showDistribution(){
    svc.showDistribution();
    return "SUCCESS";
  }
}
