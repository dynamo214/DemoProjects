package com.demo.service.PaymentMethodService;

import com.demo.dto.Bank;
import com.demo.dto.PaymentMethod;
import com.demo.service.Bank.BankFactory;
import com.demo.service.Bank.BankService;
import com.demo.service.PaymentMethodService.CardPaymentMethod;
import java.util.Map;
import java.util.Random;

public class DebitCardPaymentMethod extends CardPaymentMethod {

  Map<Integer, Bank> trafficRouting = Map.of(
      9, Bank.HDFC,
      8, Bank.HDFC,
      7, Bank.HDFC,
      6, Bank.HDFC,
      5, Bank.HDFC,
      4, Bank.HDFC,
      3, Bank.HDFC,
      2, Bank.KOTAK,
      1, Bank.KOTAK,
      0, Bank.KOTAK
  );

  public DebitCardPaymentMethod(PaymentMethod paymentMethod, Map<String, String> paymentDetails) {
    super(paymentMethod, paymentDetails);
  }

  @Override
  public boolean isValidPayment() {
    return super.isValidPayment();
  }

  @Override
  public void processPayment() throws Exception {
    Random rand = new Random();
    int randValue = rand.nextInt(10);
    Bank bank = trafficRouting.get(randValue);
    BankService client = BankFactory.getBankService(bank, paymentDetails);
    client.processPayment();
  }
}
