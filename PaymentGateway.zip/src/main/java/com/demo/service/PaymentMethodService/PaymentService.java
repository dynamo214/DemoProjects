package com.demo.service.PaymentMethodService;

import com.demo.dto.PaymentRequest;
import org.springframework.stereotype.Component;

@Component
public class PaymentService {

  public void makePayment(PaymentRequest req) throws Exception {
    BasePaymentMethod paymentMethodSvc = PaymentMethodFactory.getPaymentMethodService(req.paymentMethod(), req.paymentDetails());
    if(!paymentMethodSvc.isValidPayment()) {
      throw new Exception("Invalid payment");
    }

    paymentMethodSvc.processPayment();
  }

  public void showDistribution() {
  }
}
