package com.demo.service.PaymentMethodService;

import com.demo.dto.PaymentMethod;
import java.util.Arrays;
import java.util.Map;

public class PaymentMethodFactory {

  public static BasePaymentMethod getPaymentMethodService(PaymentMethod paymentMethod, Map<String, String> paymentDetails) throws Exception {
    if(PaymentMethod.UPI.equals(paymentMethod)) {
      return new UPIPaymentMethod(paymentMethod, paymentDetails);
    } else if(PaymentMethod.CREDIT_CARD.equals(paymentMethod)) {
      return new CreditCardPaymentMethod(paymentMethod, paymentDetails);
    } else if(PaymentMethod.DEBIT_CARD.equals(paymentMethod)) {
      return new DebitCardPaymentMethod(paymentMethod, paymentDetails);
    } else if(PaymentMethod.NET_BANKING.equals(paymentMethod)) {
      return new NetBankingPaymentMethod(paymentMethod, paymentDetails);
    }

    throw new Exception("Invalid payment method received " + paymentMethod + " allowed payment methods are " + Arrays.toString(
        PaymentMethod.values()));
  }
}
