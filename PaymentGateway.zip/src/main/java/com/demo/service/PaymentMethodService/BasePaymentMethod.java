package com.demo.service.PaymentMethodService;

import com.demo.dto.PaymentMethod;
import java.util.Map;

abstract public class BasePaymentMethod {

  PaymentMethod paymentMethod;
  Map<String, String> paymentDetails;

  BasePaymentMethod(PaymentMethod paymentMethod, Map<String, String> paymentDetails) {
    this.paymentMethod = paymentMethod;
    this.paymentDetails = paymentDetails;
  }

  abstract boolean isValidPayment();
  abstract void processPayment() throws Exception;
}
