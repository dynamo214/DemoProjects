package com.demo.service.PaymentMethodService;

import com.demo.dto.PaymentMethod;
import com.demo.service.PaymentMethodService.BasePaymentMethod;
import io.micrometer.common.util.StringUtils;
import java.time.Instant;
import java.util.Map;

public class CardPaymentMethod extends BasePaymentMethod {

  private final int ALLOWED_CVV_LENGTH = 3;

  CardPaymentMethod(PaymentMethod paymentMethod,
      Map<String, String> paymentDetails) {
    super(paymentMethod, paymentDetails);
  }

  @Override
  public boolean isValidPayment() {
    if(StringUtils.isEmpty(paymentDetails.get("card_details")) ||
        StringUtils.isEmpty(paymentDetails.get("expiry_date")) ||
        StringUtils.isEmpty(paymentDetails.get("cvv"))) {
      return false;
    }

    String expiryDate = paymentDetails.get("expiry_date");
    Instant expireDateInstant = Instant.parse(expiryDate);
    if(expireDateInstant.isBefore(Instant.now())) {
      return false;
    }

    String cvv = paymentDetails.get("cvv");
    if(cvv.length() != ALLOWED_CVV_LENGTH) {
      return false;
    }
    return true;
  }

  @Override
  public void processPayment() throws Exception {

  }
}
