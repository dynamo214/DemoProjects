package com.demo.service.PaymentMethodService;

import com.demo.dto.Bank;
import com.demo.dto.PaymentMethod;
import com.demo.service.Bank.BankFactory;
import com.demo.service.Bank.BankService;
import com.demo.service.PaymentMethodService.BasePaymentMethod;
import io.micrometer.common.util.StringUtils;
import java.util.Map;
import java.util.Random;

public class UPIPaymentMethod extends BasePaymentMethod {

  Map<Integer, Bank> trafficRouting = Map.of(
      9, Bank.HDFC,
      8, Bank.HDFC,
      7, Bank.HDFC,
      6, Bank.HDFC,
      5, Bank.HDFC,
      4, Bank.HDFC,
      3, Bank.HDFC,
      2, Bank.HDFC,
      1, Bank.HDFC,
      0, Bank.HDFC
      );

  public UPIPaymentMethod(PaymentMethod paymentMethod, Map<String, String> paymentDetails) {
    super(paymentMethod, paymentDetails);
  }

  @Override
  public boolean isValidPayment() {
    if(StringUtils.isEmpty(paymentDetails.get("vpa"))) {
      return false;
    }

    return true;
  }

  @Override
  public void processPayment() throws Exception {
    Random rand = new Random();
    int randValue = rand.nextInt(10); // [0, 9]
    Bank bank = trafficRouting.get(randValue);
    BankService client = BankFactory.getBankService(bank, paymentDetails);
    client.processPayment();
  }
}
