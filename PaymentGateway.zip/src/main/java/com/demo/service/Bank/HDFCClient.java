package com.demo.service.Bank;

import java.util.Map;

public class HDFCClient extends BankService {

  HDFCClient(Map<String, String> payload) {
    super(payload);
  }

  @Override
  public void processPayment() {

  }

}
