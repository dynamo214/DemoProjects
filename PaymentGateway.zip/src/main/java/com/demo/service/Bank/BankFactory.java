package com.demo.service.Bank;

import com.demo.dto.Bank;
import java.util.Arrays;
import java.util.Map;

public class BankFactory {
  public static BankService getBankService(Bank bank, Map<String, String> payload) throws Exception {
    if(Bank.HDFC.equals(bank)) {
      return new HDFCClient(payload);
    } else if(Bank.KOTAK.equals(bank)) {
      return null;
    }

    throw new Exception("Invalid bank received " + bank + " allowed banks are " + Arrays.toString(
        Bank.values()));
  }
}
