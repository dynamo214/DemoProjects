package com.demo.service.Bank;

import java.util.Map;

abstract public class BankService {

  Map<String, String> payload;
  BankService(Map<String, String> payload) {
    this.payload = payload;
  }

  abstract public void processPayment();
}
