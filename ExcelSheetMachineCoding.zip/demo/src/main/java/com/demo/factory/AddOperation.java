package com.demo.factory;

import com.demo.dto.Cell;
import java.util.List;

public class AddOperation implements Operation {

  @Override
  public Object perform(List<Cell> cells) {
    int value = Integer.parseInt(cells.get(0).value());
    for(int index = 1; index < cells.size(); index++) {
      value += Integer.parseInt(cells.get(index).value());
    }
    return value;
  }
}
