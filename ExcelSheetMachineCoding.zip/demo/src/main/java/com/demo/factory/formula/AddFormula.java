package com.demo.factory.formula;

import com.demo.dto.Cell;
import java.util.List;

public class AddFormula implements Formula {
  @Override
  public List<Cell> perform(List<Cell> cells, int value) {
    return null;
  }
}
