package com.demo.factory.formula;

import com.demo.enums.FormulaType;

public class FormulaFactory {
  public static Formula getFormula(FormulaType formulaType) {
    Formula formula = switch(formulaType) {
      case ADD -> new AddFormula();
    };
    return formula;
  }
}
