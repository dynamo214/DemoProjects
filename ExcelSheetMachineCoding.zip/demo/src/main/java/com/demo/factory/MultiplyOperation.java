package com.demo.factory;

import com.demo.dto.Cell;
import java.util.List;

public class MultiplyOperation implements Operation {

  @Override
  public Object perform(List<Cell> cells) {
    return null;
  }
}
