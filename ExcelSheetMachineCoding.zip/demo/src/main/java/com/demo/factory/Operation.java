package com.demo.factory;

import com.demo.dto.Cell;
import java.util.List;

public interface Operation {
  Object perform(List<Cell> cells);
}
