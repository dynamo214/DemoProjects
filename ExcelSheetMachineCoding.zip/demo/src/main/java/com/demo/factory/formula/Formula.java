package com.demo.factory.formula;

import com.demo.dto.Cell;
import java.util.List;

public interface Formula {
  public List<Cell> perform(List<Cell> cells, int value);
}
