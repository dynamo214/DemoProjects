package com.demo.factory;

import com.demo.enums.OperationType;

public class OperationFactory {

    public static Operation getOperation(OperationType operationType) {
      Operation operation = switch(operationType) {
        case ADD -> new AddOperation();
        case SUBSTRACT -> new SubstractOperation();
        case MULTIPLY -> new MultiplyOperation();
        case DIVIDE -> new DivideOperation();
      };
      return operation;
    }

}
