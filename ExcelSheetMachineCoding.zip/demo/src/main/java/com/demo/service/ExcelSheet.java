package com.demo.service;

import static com.demo.factory.OperationFactory.getOperation;
import static com.demo.factory.formula.FormulaFactory.getFormula;
import com.demo.dto.Cell;
import com.demo.dto.DependencyList;
import com.demo.enums.FormulaType;
import com.demo.enums.OperationType;
import com.demo.factory.Operation;
import com.demo.factory.formula.Formula;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class ExcelSheet {

  int rowCount;
  int colCount;
  ArrayList<ArrayList<Cell>> data;

  String DEFAULT_VALUE = "#";
  String DEFAULT_COLOR = "#ABCDEF";
  String DEFAULT_FONTSTYLE = "ComicSans";
  int DEFAULT_FONTSIZE = 10;

  public ExcelSheet(int rowCount, int colCount) {
    this.rowCount = rowCount;
    this.colCount = colCount;
    this.data = prepareEmptySheetData(rowCount, colCount);
  }

  private ArrayList<ArrayList<Cell>> prepareEmptySheetData(int rowCount, int colCount) {
    ArrayList<ArrayList<Cell>> data = new ArrayList<>();

    for(int rowIndex=0; rowIndex<rowCount; rowIndex++) {
      ArrayList<Cell> currentRow = new ArrayList<>();
      for(int colIndex=0; colIndex<colCount; colIndex++) {
        currentRow.add(
            new Cell(rowIndex, colIndex, DEFAULT_VALUE, DEFAULT_COLOR, DEFAULT_FONTSTYLE, DEFAULT_FONTSIZE, null)
        );
      }
      data.add(currentRow);
    }

    return data;
  }

  public void print() {
    for(int rowIndex=0; rowIndex<rowCount; rowIndex++) {
      for(int colIndex=0; colIndex<colCount; colIndex++) {
        System.out.print(data.get(rowIndex).get(colIndex).value() + " ");
      }
      System.out.println();
    }
    System.out.println();
  }


  public void updateCell(int rowIndex, int colIndex, HashMap<String, Object> updatedConfig)
      throws Exception {

    if(!isValidIndex(rowIndex, colIndex)) {
      throw new Exception("Invalid input");
    }

    DependencyList dependencyList = (DependencyList) updatedConfig.get("dependencyList");

    if(dependencyList == null) {
      Cell existingCell = this.data.get(rowIndex).get(colIndex);

      Cell updatedCell = new Cell(
          existingCell.rowNumber(),
          existingCell.colNumber(),
          updatedConfig.get("value") == null  ? existingCell.value() : (String) updatedConfig.get("value"),
          updatedConfig.get("color") == null  ? existingCell.color() : (String) updatedConfig.get("color"),
          updatedConfig.get("fontStyle") == null  ? existingCell.fontStyle() : (String) updatedConfig.get("fontStyle"),
          updatedConfig.get("fontSize") == null  ? existingCell.fontSize() : (int) updatedConfig.get("fontSize"),
          existingCell.dependencyList()
      );
      this.data.get(rowIndex).set(colIndex, updatedCell);
    } else {
      String value = dependencyList.getValue();
      Cell existingCell = this.data.get(rowIndex).get(colIndex);
      Cell updatedCell = new Cell(
          existingCell.rowNumber(),
          existingCell.colNumber(),
          value,
          updatedConfig.get("color") == null  ? existingCell.color() : (String) updatedConfig.get("color"),
          updatedConfig.get("fontStyle") == null  ? existingCell.fontStyle() : (String) updatedConfig.get("fontStyle"),
          updatedConfig.get("fontSize") == null  ? existingCell.fontSize() : (int) updatedConfig.get("fontSize"),
          existingCell.dependencyList()
      );
      this.data.get(rowIndex).set(colIndex, updatedCell);
    }
  }

  public String getCell(int rowIndex, int colIndex) {
    // validation
    return this.data.get(rowIndex).get(colIndex).value();
  }

  public void executeFormula(int startRow, int endRow, int startCol, int endCol, FormulaType formulaType, int value) {

    // TODO: add validations
    List<Cell> cells = new ArrayList<>();
    for(int rowIndex=startRow; rowIndex<=endRow; rowIndex++) {
      for(int colIndex=startCol; colIndex<endCol; colIndex++) {
        cells.add(this.data.get(rowIndex).get(colIndex));
      }
    }
    Formula formula = getFormula(formulaType);
    List<Cell> updatedCells = formula.perform(cells, value);

    // update updatedCells in sheet
  }

  public boolean isValidIndex(int rowIndex, int colIndex) {
    return rowIndex >= 0 && colIndex >= 0 && rowIndex < this.rowCount && colIndex < this.colCount;
  }
}
