package com.demo.dto;

import java.util.List;

public record Sheet(int rowCount, int colCount, List<List> Cell) {

}
