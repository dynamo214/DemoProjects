package com.demo.dto;

public record Cell(int rowNumber, int colNumber, String value, String color, String fontStyle, int fontSize, DependencyList dependencyList) {

}
