package com.demo.dto;

import static com.demo.factory.OperationFactory.getOperation;
import com.demo.enums.OperationType;
import com.demo.factory.Operation;
import java.util.List;

public record DependencyList(List<Cell> cells, OperationType operationType) {

    public String getValue() {
        Operation operation = getOperation(operationType);
        return (String) operation.perform(cells);
    }
}
