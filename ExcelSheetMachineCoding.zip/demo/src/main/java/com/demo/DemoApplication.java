package com.demo;

import com.demo.service.ExcelSheet;
import java.util.HashMap;
import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) throws Exception {
//		SpringApplication.run(DemoApplication.class, args);

		int rowCount = 5, colCount = 5;
		ExcelSheet execelSheet = new ExcelSheet(rowCount, colCount);
		execelSheet.print();
		execelSheet.updateCell(1, 1, new HashMap<>(Map.of(
				"value", "10"
		)));
		execelSheet.updateCell(2, 2, new HashMap<>(Map.of(
				"value", "20"
		)));
		execelSheet.print();
	}

}

/*
Implement a single excel sheet of data

Features:
Print entire excel sheet
Update value of a cell
Get value of a cell
Add Basic formulae such as add, subtract, multiply
Add range operations such as sum() over range.
Conditional functions based on other cells
Conditional formatting of cells


1. Print entire excel sheet -> iterate through row and col -> print cell value
2. Update value of a cell -> (row, col, value, dependencyList))
3. Get value of a cell -> (row, col)
4. Add Basic formulae such as add, subtract, multiply -> (startRow, endRow, startCol, endCol, operation, value)
operation -> add/substract/multiply
factory pattern


row=1000, col=1000
1000*1000

Add range operations such as sum() over range. -> sum(startRow, endRow) or sum(startCol, endCol)
Conditional functions based on other cells -> connected cells/rows, changing one row/col value changes other rows/cols
Conditional formatting of cells->color, font_style, font_size


1.Sheet -> 2D Array Cells
- data
[
	[Cell1], [Cell2], [Cell3], [Cell4]...
	[Cell1], [Cell2], [Cell3]...
]

2.
Cell
- value
- rowNumber
- colNumber
- color
- fontStyle
- fontSize
- dependencyList
	-cells [Cell1, Cell2],
	-customInput {"multiplier": 4}}
	-operation(native=add/subs/mul/divide, custom)

Cell5 = Cell1 +/-* Cell2
Call5 = 4 * Cell2

 */