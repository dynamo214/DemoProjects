package com.demo.enums;

public enum OperationType {
  ADD,
  SUBSTRACT,
  MULTIPLY,
  DIVIDE
}
