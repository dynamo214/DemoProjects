package com.demo.enums;

public enum FormulaType {
  ADD
}
